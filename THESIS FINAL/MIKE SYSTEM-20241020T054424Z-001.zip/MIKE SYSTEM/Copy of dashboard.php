<?php
include 'db.php';
session_start();

if ($_SESSION['role'] != 'admin') {
    die("Access denied!");
}

$reservations = $conn->query("SELECT * FROM reservations")->fetchAll();
?>

<h2>Reservations</h2>
<table>
    <tr>
        <th>ID</th>
        <th>User ID</th>
        <th>Check-in</th>
        <th>Check-out</th>
        <th>Status</th>
        <th>Payment Status</th>
    </tr>
    <?php foreach ($reservations as $res): ?>
    <tr>
        <td><?= $res['id'] ?></td>
        <td><?= $res['user_id'] ?></td>
        <td><?= $res['check_in'] ?></td>
        <td><?= $res['check_out'] ?></td>
        <td><?= $res['status'] ?></td>
        <td><?= $res['payment_status'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>
