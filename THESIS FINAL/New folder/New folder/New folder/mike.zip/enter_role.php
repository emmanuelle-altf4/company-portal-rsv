<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $role = $_POST['role'];

    $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
    $stmt->execute([$role, $user_id]);

    echo "User role updated successfully!";
}
?>

<form method="POST">
    <input type="number" name="user_id" placeholder="User ID" required>
    <select name="role">
        <option value="guest">Guest</option>
        <option value="admin">Admin</option>
    </select>
    <button type="submit">Update Role</button>
</form>
